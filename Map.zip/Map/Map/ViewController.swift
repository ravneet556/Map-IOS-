//
//  ViewController.swift
//  Map
//
//  Created by Ravneet kaur on 2020-06-17.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
class ViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate  {

    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var myTextView: UITextView!
    var myAnnotations = [CLLocation]()
    let locationManager = CLLocationManager()
    var current = 0
    var titles = ["A","B","c","D","E"]
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
  
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters; locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        mapView.showsUserLocation = true
        
        mapView.delegate = self 
        let longGesture = UITapGestureRecognizer(target: self, action: #selector(addPin(longGesture:)))
        mapView.addGestureRecognizer(longGesture)
        
       
       
    }
    
    
    
    @objc func addPin(longGesture: UIGestureRecognizer) {
       
            
        if myAnnotations.count  < 5{
            
        let touchPoint = longGesture.location(in: mapView)
        let touchLocation = mapView.convert(touchPoint, toCoordinateFrom: mapView)
         
    let location = CLLocation(latitude: touchLocation.latitude, longitude: touchLocation.longitude)
    let myAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = touchLocation
        myAnnotation.title = titles[current]
        myAnnotations.append(location)
        self.mapView.addAnnotation(myAnnotation)
            
          
            }
            current = current + 1

    
    }
        
    func addPolyline(coordinates: [CLLocationCoordinate2D]){
        
    }
   
   func mapView(_ MapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
       if annotation is MKUserLocation {
           return nil
       }

       let view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "pin")
       view.markerTintColor = .blue
       return view
   }

    
   
}

